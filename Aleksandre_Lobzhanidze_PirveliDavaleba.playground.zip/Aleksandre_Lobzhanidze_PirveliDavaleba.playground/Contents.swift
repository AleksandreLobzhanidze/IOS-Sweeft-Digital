import UIKit

//პირველი დავალება

func ispalindrome( sitkva : String) -> Bool{
    guard sitkva.count >= 2 else {
    return true
    }
    var result = String(sitkva.reversed())

    if result == sitkva{
        return true
    }else{
        return false
    }
}
print(ispalindrome(sitkva: "ana"))


//პირველი დავალების მეტი ვერ გავაკეთე აქ არის ნაწერები სხვა დავალებების


//func xurda( fulisList: Int) -> (Int & String){
//    let ormocdaati = "50 თეთრი"
//    let change = 50
//    if fulisList > change {
//        let xurda = fulisList / change
//        return xurda
//        return ormocdaati
//    }else{
//        return fulisList
//    }
//}
//print(xurda(fulisList: 100))



//var array = [5, 10, 3, 6, 8]
//func lowerNumber(numbers: [Int]) -> Array<Int>{
//    var numbers2 = numbers
//    var gamokleba = numbers2.count - 1
//    for i in 0...gamokleba {
//        if (numbers2[i] > 0){
//            numbers2.remove(at: i)
//        }
//    }
//    return numbers2
//}
//
//print(lowerNumber(array))

//func xurda(fuliAmount: Int) -> Int{
//    let fifty = fuliAmount
//    let twenty = fuliAmount % 50
//    let ten = fuliAmount % 50 % 20
//    let five = fuliAmount % 50 % 20 % 10
//    let two = fuliAmount % 50 % 20 % 10 % 5
//    let one = fuliAmount % 50 % 20 % 10 % 5 % 2
//    var kvela = [fifty, twenty, ten, five,two, one]
//}
//
//print(xurda(fuliAmount: 150))


